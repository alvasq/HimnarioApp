import NetInfo from '@react-native-community/netinfo';
import Slider from '@react-native-community/slider';
import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useEffect, useRef, useState } from 'react';
import {
    ActivityIndicator,
    AppState,
    BackHandler,
    StyleSheet,
    Text,
    TouchableOpacity,
    View
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Video, { OnLoadData, OnProgressData, VideoRef } from 'react-native-video';
import { PlayerScreenNavigationProp, PlayerScreenRouteProp } from '../navigation/types';
import { checkFileExists, getSongFilePath } from '../services/downloader';

type RepeatMode = 'none' | 'one' | 'all';

const PlayerScreen: React.FC = () => {
    const navigation = useNavigation<PlayerScreenNavigationProp>();
    const route = useRoute<PlayerScreenRouteProp>();
    const { song, songList, autoplay = false } = route.params;
    const [paused, setPaused] = useState(!autoplay);
    const [duration, setDuration] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(false);
    const [isLocal, setIsLocal] = useState(false);
    const [hasInternet, setHasInternet] = useState(true);
    const [shuffle, setShuffle] = useState(false);
    const [repeatMode, setRepeatMode] = useState<RepeatMode>('none');
    const playerRef = useRef<VideoRef>(null);

    const [audioUrl, setAudioUrl] = useState('');

    // Manejar el estado de la canción actual
    useEffect(() => {
        navigation.setParams({ currentSong: song });
    }, [song, navigation]);

    // Configurar el botón de retroceso
    useEffect(() => {
        const backAction = () => {
            navigation.navigate('Home', { currentSong: song });
            return true; // Evitar que se cierre el reproductor
        };

        const backHandler = BackHandler.addEventListener(
            'hardwareBackPress',
            backAction
        );

        return () => backHandler.remove();
    }, [navigation, song]);

    // No pausar al cambiar entre apps
    useEffect(() => {
        const subscription = AppState.addEventListener('change', (nextAppState) => {
            if (nextAppState === 'active') {
                console.log('App en primer plano - reproducción continua');
            }
        });

        return () => {
            subscription.remove();
        };
    }, []);

    // Verificar conexión a internet
    useEffect(() => {
        const unsubscribe = NetInfo.addEventListener(state => {
            setHasInternet(state.isConnected ?? false);
        });

        return () => unsubscribe();
    }, []);

    // Inicializar reproductor
    useEffect(() => {
        const initializePlayer = async () => {
            setIsLoading(true);
            setError(false);

            try {
                const fileExists = await checkFileExists(song);
                setIsLocal(fileExists);

                if (fileExists) {
                    setAudioUrl(getSongFilePath(song));
                } else {
                    if (!hasInternet) {
                        throw new Error('No internet connection');
                    }
                    setAudioUrl(`https://img.solt.gt/${song.category}/${song.id}_${song.title.replace(/\s+/g, '_')}.mp3`);
                }
            } catch (err) {
                setError(true);
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };

        initializePlayer();
    }, [song, hasInternet]);

    // Auto-play al cargar
    useEffect(() => {
        if (autoplay && audioUrl && !isLoading && !error) {
            setPaused(false);
        }
    }, [autoplay, audioUrl, isLoading, error]);

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
    };

    const handleSliderChange = (value: number) => {
        setCurrentTime(value);
        if (playerRef.current) {
            playerRef.current.seek(value);
        }
    };

    const togglePlayback = () => {
        if (error) return;
        setPaused(!paused);
    };

    const handleLoad = (data: OnLoadData) => {
        setDuration(data.duration);
        setIsLoading(false);
    };

    const handleProgress = (data: OnProgressData) => {
        setCurrentTime(data.currentTime);
    };

    const getRandomSong = (currentId: string) => {
        const availableSongs = songList.filter(s => s.id !== currentId);
        if (availableSongs.length === 0) return songList[0];
        const randomIndex = Math.floor(Math.random() * availableSongs.length);
        return availableSongs[randomIndex];
    };

    const handleNext = () => {
        let nextSong;

        if (shuffle) {
            nextSong = getRandomSong(song.id);
        } else {
            const currentIndex = songList.findIndex(s => s.id === song.id);
            nextSong = currentIndex < songList.length - 1
                ? songList[currentIndex + 1]
                : songList[0];
        }

        navigation.setParams({
            song: nextSong,
            songList: songList,
            autoplay: true
        });
    };

    const handlePrevious = () => {
        let prevSong;

        if (shuffle) {
            prevSong = getRandomSong(song.id);
        } else {
            const currentIndex = songList.findIndex(s => s.id === song.id);
            prevSong = currentIndex > 0
                ? songList[currentIndex - 1]
                : songList[songList.length - 1];
        }

        navigation.setParams({
            song: prevSong,
            songList: songList,
            autoplay: true
        });
    };

    const handleEnd = () => {
        if (repeatMode === 'one') {
            playerRef.current?.seek(0);
            setPaused(false);
        } else if (repeatMode === 'all' || shuffle) {
            handleNext();
        } else {
            setPaused(true);
        }
    };

    const toggleShuffle = () => {
        setShuffle(!shuffle);
    };

    const toggleRepeatMode = () => {
        const modes: RepeatMode[] = ['none', 'one', 'all'];
        const currentIndex = modes.indexOf(repeatMode);
        const nextIndex = (currentIndex + 1) % modes.length;
        setRepeatMode(modes[nextIndex]);
    };

    return (
        <View style={styles.container}>
            <Video
                ref={playerRef}
                source={{ uri: audioUrl }}
                paused={paused}
                onLoad={handleLoad}
                onProgress={handleProgress}
                onEnd={handleEnd}
                onError={() => {
                    setError(true);
                    setIsLoading(false);
                }}
                onLoadStart={() => setIsLoading(true)}
                playInBackground={true}
                playWhenInactive={true}
                ignoreSilentSwitch="ignore"
                style={styles.audioElement}
            />

            <View style={styles.songInfo}>
                <View style={styles.albumArt}>
                    {isLoading ? (
                        <ActivityIndicator size="large" color="#555" />
                    ) : error ? (
                        <Icon name="error-outline" size={60} color="#ff4444" />
                    ) : (
                        <Icon name="music-note" size={80} color="#888" />
                    )}
                </View>

                <View style={styles.sourceIndicator}>
                    <Icon
                        name={isLocal ? 'check-circle' : 'cloud'}
                        size={16}
                        color={isLocal ? '#4CAF50' : '#2196F3'}
                    />
                    <Text style={styles.sourceText}>
                        {isLocal ? 'Reproduciendo local' : 'Reproduciendo desde internet'}
                    </Text>
                </View>

                <Text style={styles.songTitle}>{song.title}</Text>
                <Text style={styles.songArtist}>{song.artist || 'Artista desconocido'}</Text>

                <View style={styles.progressContainer}>
                    <Slider
                        style={styles.progressBar}
                        minimumValue={0}
                        maximumValue={duration || 1}
                        value={currentTime}
                        onSlidingComplete={handleSliderChange}
                        minimumTrackTintColor="#555"
                        maximumTrackTintColor="#e0e0e0"
                        thumbTintColor="#555"
                        disabled={error || isLoading}
                    />
                    <View style={styles.timeContainer}>
                        <Text style={styles.timeText}>{formatTime(currentTime)}</Text>
                        <Text style={styles.timeText}>{formatTime(duration)}</Text>
                    </View>
                </View>
            </View>

            <View style={styles.controls}>
                <TouchableOpacity
                    style={styles.controlButton}
                    onPress={handlePrevious}
                    disabled={error || isLoading}
                >
                    <Icon name="skip-previous" size={32} color={error || isLoading ? "#ccc" : "#555"} />
                </TouchableOpacity>

                <TouchableOpacity
                    style={[styles.playButton, (error || isLoading) && styles.disabledButton]}
                    onPress={togglePlayback}
                    disabled={error || isLoading}
                >
                    {isLoading ? (
                        <ActivityIndicator size="small" color="#fff" />
                    ) : (
                        <Icon
                            name={paused ? 'play-arrow' : 'pause'}
                            size={32}
                            color="#fff"
                        />
                    )}
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.controlButton}
                    onPress={handleNext}
                    disabled={error || isLoading}
                >
                    <Icon name="skip-next" size={32} color={error || isLoading ? "#ccc" : "#555"} />
                </TouchableOpacity>
            </View>

            <View style={styles.secondaryControls}>
                <TouchableOpacity
                    style={styles.secondaryButton}
                    onPress={toggleShuffle}
                    disabled={error || isLoading}
                >
                    <Icon
                        name="shuffle"
                        size={24}
                        color={shuffle ? "#555" : (error || isLoading ? "#ccc" : "#777")}
                    />
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.secondaryButton}
                    onPress={toggleRepeatMode}
                    disabled={error || isLoading}
                >
                    <Icon
                        name={repeatMode === 'one' ? 'repeat-one' : 'repeat'}
                        size={24}
                        color={repeatMode !== 'none' ? "#555" : (error || isLoading ? "#ccc" : "#777")}
                    />
                </TouchableOpacity>

                <TouchableOpacity style={styles.secondaryButton} disabled={error || isLoading}>
                    <Icon name="favorite-border" size={24} color={error || isLoading ? "#ccc" : "#777"} />
                </TouchableOpacity>

                <TouchableOpacity style={styles.secondaryButton} disabled={error || isLoading}>
                    <Icon name="more-vert" size={24} color={error || isLoading ? "#ccc" : "#777"} />
                </TouchableOpacity>
            </View>

            {error && (
                <Text style={styles.errorText}>
                    {!hasInternet && !isLocal
                        ? 'No hay conexión a internet y la canción no está descargada'
                        : 'Error al cargar el audio. Verifica tu conexión o la URL del recurso.'}
                </Text>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        paddingHorizontal: 20,
        justifyContent: 'center',
    },
    audioElement: {
        width: 0,
        height: 0,
        position: 'absolute',
    },
    songInfo: {
        alignItems: 'center',
        marginBottom: 40,
    },
    albumArt: {
        width: 220,
        height: 220,
        backgroundColor: '#f5f5f5',
        borderRadius: 8,
        marginBottom: 25,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#e0e0e0',
    },
    sourceIndicator: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    sourceText: {
        fontSize: 14,
        color: '#666',
        marginLeft: 5,
    },
    songTitle: {
        fontSize: 22,
        fontWeight: '600',
        color: '#333',
        marginBottom: 5,
        textAlign: 'center',
    },
    songArtist: {
        fontSize: 16,
        color: '#666',
        marginBottom: 30,
    },
    progressContainer: {
        width: '100%',
        marginBottom: 40,
    },
    progressBar: {
        width: '100%',
        height: 40,
    },
    timeContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 5,
    },
    timeText: {
        fontSize: 12,
        color: '#888',
    },
    controls: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 40,
    },
    controlButton: {
        marginHorizontal: 25,
    },
    playButton: {
        backgroundColor: '#555',
        width: 70,
        height: 70,
        borderRadius: 35,
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 5,
    },
    disabledButton: {
        backgroundColor: '#ccc',
    },
    secondaryControls: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        paddingHorizontal: 40,
    },
    secondaryButton: {
        padding: 10,
    },
    errorText: {
        color: '#ff4444',
        textAlign: 'center',
        marginTop: 10,
        fontSize: 14,
    },
});

export default PlayerScreen;