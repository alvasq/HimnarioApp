export type Song = {
  id: string;
  title: string;
  category: 'himnos' | 'coros';
  duration: string;
  artist?: string;
  downloaded?: boolean;
};
